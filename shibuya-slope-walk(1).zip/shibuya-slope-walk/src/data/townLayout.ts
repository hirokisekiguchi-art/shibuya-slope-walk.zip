import { colors } from './colors';
import { roadCenterX, slopeHeight } from '../utils/terrain';

export type BuildingSide = 'left' | 'right';

export interface BuildingConfig {
  id: string;
  side: BuildingSide;
  z: number;
  width: number;
  height: number;
  depth: number;
  color: string;
  yaw: number;
  variant: 'shop' | 'apartment' | 'house' | 'office';
  signColor?: string;
}

const leftOffset = 5.9;
const rightOffset = 5.7;

export const buildings: BuildingConfig[] = [
  { id: 'l-shop-01', side: 'left', z: -2, width: 3.5, height: 4.1, depth: 4.6, color: colors.buildingBeige, yaw: -0.1, variant: 'shop', signColor: colors.signOrange },
  { id: 'r-office-01', side: 'right', z: -5, width: 3.8, height: 5.2, depth: 4.2, color: colors.buildingGrey, yaw: 0.14, variant: 'office', signColor: colors.buildingGreen },
  { id: 'l-apartment-01', side: 'left', z: -9, width: 4.4, height: 6.0, depth: 4.0, color: colors.buildingCream, yaw: 0.08, variant: 'apartment', signColor: '#79A7A1' },
  { id: 'r-house-01', side: 'right', z: -12, width: 3.5, height: 4.4, depth: 3.8, color: colors.buildingGreen, yaw: -0.08, variant: 'house', signColor: colors.signOrange },
  { id: 'l-office-02', side: 'left', z: -17, width: 3.7, height: 7.0, depth: 4.7, color: colors.buildingBlueGrey, yaw: -0.2, variant: 'office', signColor: '#AEBE77' },
  { id: 'r-shop-02', side: 'right', z: -20, width: 4.3, height: 5.0, depth: 4.1, color: colors.buildingBeige, yaw: 0.12, variant: 'shop', signColor: '#76A0B4' },
  { id: 'l-house-02', side: 'left', z: -25, width: 4.2, height: 4.8, depth: 4.2, color: '#B5BBA9', yaw: 0.12, variant: 'house', signColor: colors.signOrange },
  { id: 'r-apartment-02', side: 'right', z: -28, width: 4.4, height: 7.2, depth: 4.5, color: '#A7B09B', yaw: -0.18, variant: 'apartment', signColor: '#D1B26A' },
  { id: 'l-shop-03', side: 'left', z: -34, width: 3.8, height: 5.4, depth: 4.2, color: '#B9B2A1', yaw: -0.04, variant: 'shop', signColor: '#6A9E9A' },
  { id: 'r-office-03', side: 'right', z: -37, width: 4.6, height: 6.8, depth: 4.2, color: '#9FA9A4', yaw: 0.1, variant: 'office', signColor: colors.signOrange },
  { id: 'l-apartment-04', side: 'left', z: -43, width: 4.6, height: 6.4, depth: 4.0, color: '#B4B99D', yaw: 0.18, variant: 'apartment', signColor: '#7AA79E' },
  { id: 'r-house-04', side: 'right', z: -46, width: 3.9, height: 4.9, depth: 4.0, color: '#C4BDA4', yaw: -0.12, variant: 'house', signColor: '#D1943D' },
];

export function buildingPosition(config: BuildingConfig): [number, number, number] {
  const sideSign = config.side === 'left' ? -1 : 1;
  const offset = config.side === 'left' ? leftOffset : rightOffset;
  const x = roadCenterX(config.z) + sideSign * offset;
  const y = slopeHeight(config.z) + config.height / 2;
  return [x, y, config.z];
}

export const roadSegments = Array.from({ length: 13 }, (_, index) => {
  const z = 2 - index * 4.7;
  return {
    id: `road-${index}`,
    z,
    x: roadCenterX(z),
    y: slopeHeight(z) - 0.07,
    yaw: Math.sin(index * 0.55) * 0.08,
  };
});
