import { colors } from '../../data/colors';
import { ToonBox } from '../toon/ToonBox';
import { ToonSphere } from '../toon/ToonSphere';

interface PlayerBodyProps {
  moving: boolean;
}

export function PlayerBody({ moving }: PlayerBodyProps) {
  return (
    <group rotation={[0, Math.PI, 0]}>
      <mesh position={[0, 0.035, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <circleGeometry args={[0.58, 24]} />
        <meshBasicMaterial color="#314443" transparent opacity={0.24} />
      </mesh>
      <group position={[0, moving ? 0.025 : 0, 0]}>
        <ToonSphere radius={0.34} color={colors.skin} position={[0, 1.62, 0]} />
        <ToonSphere radius={0.38} color={colors.hair} position={[0, 1.75, 0.03]} widthSegments={12} heightSegments={8} />
        <ToonSphere radius={0.16} color={colors.hair} position={[-0.3, 1.82, 0.03]} widthSegments={8} heightSegments={6} />
        <ToonSphere radius={0.16} color={colors.hair} position={[0.3, 1.82, 0.03]} widthSegments={8} heightSegments={6} />

        <ToonBox size={[0.64, 0.76, 0.36]} color={colors.playerShirt} position={[0, 1.02, 0]} rotation={[0.04, 0, 0]} />
        <ToonBox size={[0.56, 0.56, 0.32]} color={colors.playerPants} position={[0, 0.45, 0]} />
        <ToonBox size={[0.22, 0.58, 0.22]} color={colors.playerPants} position={[-0.18, 0.2, 0]} />
        <ToonBox size={[0.22, 0.58, 0.22]} color={colors.playerPants} position={[0.18, 0.2, 0]} />

        <ToonBox size={[0.28, 0.18, 0.42]} color={colors.playerShoes} position={[-0.2, 0.04, -0.08]} rotation={[0, 0.12, 0]} />
        <ToonBox size={[0.28, 0.18, 0.42]} color={colors.playerShoes} position={[0.2, 0.04, -0.08]} rotation={[0, -0.12, 0]} />

        <ToonBox size={[0.18, 0.58, 0.18]} color={colors.skin} position={[-0.48, 0.9, 0]} rotation={[0.08, 0, -0.1]} />
        <ToonBox size={[0.18, 0.58, 0.18]} color={colors.skin} position={[0.48, 0.9, 0]} rotation={[0.08, 0, 0.1]} />
        <ToonBox size={[0.44, 0.6, 0.24]} color={colors.playerBag} position={[0.38, 1.02, 0.22]} rotation={[0.14, 0, -0.26]} />
        <ToonBox size={[0.08, 0.86, 0.08]} color={'#394341'} position={[0.18, 1.12, 0.25]} rotation={[0.25, 0, 0.72]} outline={false} />
      </group>
    </group>
  );
}
