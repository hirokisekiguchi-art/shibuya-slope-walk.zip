import { useFrame, useThree } from '@react-three/fiber';
import { useMemo, useRef, useState } from 'react';
import * as THREE from 'three';
import { useKeyboardControls } from '../../hooks/useKeyboardControls';
import { useMouseLook } from '../../hooks/useMouseLook';
import { clampToWalkableStreet, slopeHeight } from '../../utils/terrain';
import { PlayerBody } from './PlayerBody';

interface PlayerProps {
  started: boolean;
}

export function Player({ started }: PlayerProps) {
  const playerRef = useRef<THREE.Group>(null);
  const bodyRef = useRef<THREE.Group>(null);
  const keyboard = useKeyboardControls();
  const { yaw, pitch } = useMouseLook(started);
  const { camera } = useThree();
  const velocity = useMemo(() => new THREE.Vector3(), []);
  const desiredMove = useMemo(() => new THREE.Vector3(), []);
  const forward = useMemo(() => new THREE.Vector3(), []);
  const right = useMemo(() => new THREE.Vector3(), []);
  const cameraTarget = useMemo(() => new THREE.Vector3(), []);
  const lookTarget = useMemo(() => new THREE.Vector3(), []);
  const [moving, setMoving] = useState(false);
  const movingRef = useRef(false);

  useFrame(({ clock }, delta) => {
    const player = playerRef.current;
    if (!player) return;

    const keys = keyboard.current;
    desiredMove.set(0, 0, 0);
    forward.set(Math.sin(yaw.current), 0, -Math.cos(yaw.current));
    right.set(Math.cos(yaw.current), 0, Math.sin(yaw.current));

    if (started) {
      if (keys.forward) desiredMove.add(forward);
      if (keys.backward) desiredMove.sub(forward);
      if (keys.right) desiredMove.add(right);
      if (keys.left) desiredMove.sub(right);
    }

    const isMoving = desiredMove.lengthSq() > 0.001;
    if (isMoving) desiredMove.normalize();

    const walkSpeed = keys.sprint ? 4.1 : 2.35;
    velocity.lerp(desiredMove.multiplyScalar(walkSpeed), 0.14);
    player.position.addScaledVector(velocity, delta);
    clampToWalkableStreet(player.position);

    const baseY = slopeHeight(player.position.z);
    const bob = isMoving ? Math.sin(clock.elapsedTime * 8.0) * 0.035 : 0;
    player.position.y = baseY + bob;
    player.rotation.y = yaw.current;

    if (bodyRef.current) {
      bodyRef.current.rotation.z = isMoving ? Math.sin(clock.elapsedTime * 5.5) * 0.035 : THREE.MathUtils.lerp(bodyRef.current.rotation.z, 0, 0.12);
      bodyRef.current.rotation.x = isMoving ? Math.sin(clock.elapsedTime * 4.2) * 0.025 : THREE.MathUtils.lerp(bodyRef.current.rotation.x, 0, 0.12);
    }

    if (movingRef.current !== isMoving) {
      movingRef.current = isMoving;
      setMoving(isMoving);
    }

    const cameraDistance = 5.35;
    const cameraHeight = 2.35 + pitch.current * 2.3;
    cameraTarget
      .copy(player.position)
      .addScaledVector(forward, -cameraDistance)
      .add(new THREE.Vector3(0, cameraHeight, 0));

    camera.position.lerp(cameraTarget, 0.11);
    lookTarget.copy(player.position).addScaledVector(forward, 1.85).add(new THREE.Vector3(0, 1.18 + pitch.current * 1.4, 0));
    camera.lookAt(lookTarget);
  });

  return (
    <group ref={playerRef} position={[0, 0, 1.2]}>
      <group ref={bodyRef}>
        <PlayerBody moving={moving} />
      </group>
    </group>
  );
}
