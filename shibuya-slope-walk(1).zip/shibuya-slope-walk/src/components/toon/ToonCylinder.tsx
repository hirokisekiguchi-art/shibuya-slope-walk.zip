import type { ThreeElements } from '@react-three/fiber';
import { colors } from '../../data/colors';
import { OutlineEdges } from './OutlineEdges';

interface ToonCylinderProps extends Omit<ThreeElements['mesh'], 'scale'> {
  radiusTop?: number;
  radiusBottom?: number;
  height: number;
  radialSegments?: number;
  color: string;
  outline?: boolean;
}

export function ToonCylinder({
  radiusTop = 0.25,
  radiusBottom = 0.25,
  height,
  radialSegments = 12,
  color,
  outline = true,
  ...meshProps
}: ToonCylinderProps) {
  return (
    <mesh {...meshProps}>
      <cylinderGeometry args={[radiusTop, radiusBottom, height, radialSegments]} />
      <meshToonMaterial color={color} />
      {outline ? <OutlineEdges color={colors.outline} threshold={18} /> : null}
    </mesh>
  );
}
