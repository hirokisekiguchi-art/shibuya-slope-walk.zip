import type { ThreeElements } from '@react-three/fiber';
import { colors } from '../../data/colors';
import { OutlineEdges } from './OutlineEdges';

interface ToonSphereProps extends Omit<ThreeElements['mesh'], 'scale'> {
  radius: number;
  color: string;
  widthSegments?: number;
  heightSegments?: number;
  outline?: boolean;
}

export function ToonSphere({
  radius,
  color,
  widthSegments = 14,
  heightSegments = 10,
  outline = true,
  ...meshProps
}: ToonSphereProps) {
  return (
    <mesh {...meshProps}>
      <sphereGeometry args={[radius, widthSegments, heightSegments]} />
      <meshToonMaterial color={color} />
      {outline ? <OutlineEdges color={colors.outline} threshold={18} /> : null}
    </mesh>
  );
}
