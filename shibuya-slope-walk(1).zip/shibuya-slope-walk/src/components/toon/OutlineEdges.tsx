import { Edges } from '@react-three/drei';
import { colors } from '../../data/colors';

interface OutlineEdgesProps {
  color?: string;
  threshold?: number;
}

export function OutlineEdges({ color = colors.outline, threshold = 25 }: OutlineEdgesProps) {
  return <Edges threshold={threshold} color={color} />;
}
