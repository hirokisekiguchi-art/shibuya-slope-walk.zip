import { forwardRef } from 'react';
import type { ThreeElements } from '@react-three/fiber';
import type * as THREE from 'three';
import { colors } from '../../data/colors';
import { OutlineEdges } from './OutlineEdges';

interface ToonBoxProps extends Omit<ThreeElements['mesh'], 'scale'> {
  size: [number, number, number];
  color: string;
  outline?: boolean;
  outlineColor?: string;
  opacity?: number;
}

export const ToonBox = forwardRef<THREE.Mesh, ToonBoxProps>(function ToonBox(
  { size, color, outline = true, outlineColor = colors.outline, opacity = 1, ...meshProps },
  ref,
) {
  return (
    <mesh ref={ref} {...meshProps}>
      <boxGeometry args={size} />
      <meshToonMaterial color={color} transparent={opacity < 1} opacity={opacity} />
      {outline ? <OutlineEdges color={outlineColor} /> : null}
    </mesh>
  );
});
