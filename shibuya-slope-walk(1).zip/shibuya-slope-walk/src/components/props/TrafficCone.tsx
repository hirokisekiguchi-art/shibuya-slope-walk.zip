import { colors } from '../../data/colors';
import { ToonBox } from '../toon/ToonBox';
import { ToonCylinder } from '../toon/ToonCylinder';

interface TrafficConeProps {
  position: [number, number, number];
  rotationY?: number;
}

export function TrafficCone({ position, rotationY = 0 }: TrafficConeProps) {
  return (
    <group position={position} rotation={[0, rotationY, 0]}>
      <ToonBox size={[0.44, 0.08, 0.44]} color={colors.outlineSoft} position={[0, 0.04, 0]} />
      <ToonCylinder radiusTop={0.08} radiusBottom={0.22} height={0.68} radialSegments={4} color={colors.coneOrange} position={[0, 0.42, 0]} rotation={[0, Math.PI / 4, 0]} />
      <ToonBox size={[0.3, 0.055, 0.05]} color={colors.whiteLine} position={[0, 0.42, -0.14]} outline={false} />
    </group>
  );
}
