import { colors } from '../../data/colors';
import { ToonBox } from '../toon/ToonBox';
import { ToonCylinder } from '../toon/ToonCylinder';

interface StreetSignProps {
  position: [number, number, number];
  rotationY?: number;
  type?: 'arrow' | 'circle' | 'board';
}

export function StreetSign({ position, rotationY = 0, type = 'arrow' }: StreetSignProps) {
  return (
    <group position={position} rotation={[0, rotationY, 0]}>
      <ToonCylinder radiusTop={0.045} radiusBottom={0.045} height={2.05} color={colors.outlineSoft} position={[0, 1.02, 0]} radialSegments={8} />
      {type === 'circle' ? (
        <mesh position={[0, 1.95, 0]} rotation={[Math.PI / 2, 0, 0]}>
          <cylinderGeometry args={[0.33, 0.33, 0.045, 24]} />
          <meshToonMaterial color={'#E6EEE7'} />
          <lineSegments />
        </mesh>
      ) : (
        <ToonBox size={[0.86, 0.46, 0.06]} color={type === 'arrow' ? colors.signOrange : '#77A6A1'} position={[0, 1.92, 0]} />
      )}
      {type === 'arrow' ? (
        <>
          <ToonBox size={[0.38, 0.055, 0.07]} color={colors.outline} position={[0, 1.92, -0.04]} outline={false} />
          <ToonBox size={[0.12, 0.12, 0.07]} color={colors.outline} position={[0.22, 1.92, -0.04]} rotation={[0, 0, Math.PI / 4]} outline={false} />
        </>
      ) : null}
    </group>
  );
}
