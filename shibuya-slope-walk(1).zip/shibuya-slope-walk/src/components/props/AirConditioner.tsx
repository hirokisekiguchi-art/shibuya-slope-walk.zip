import { colors } from '../../data/colors';
import { ToonBox } from '../toon/ToonBox';

interface AirConditionerProps {
  position: [number, number, number];
  frontSign?: number;
}

export function AirConditioner({ position, frontSign = 1 }: AirConditionerProps) {
  return (
    <group position={position}>
      <ToonBox size={[0.18, 0.38, 0.72]} color={'#D5D8CB'} position={[0, 0, 0]} />
      <ToonBox size={[0.04, 0.18, 0.32]} color={colors.outlineSoft} position={[frontSign * 0.1, 0.02, 0]} outline={false} />
      <ToonBox size={[0.035, 0.42, 0.05]} color={colors.outlineSoft} position={[frontSign * 0.12, -0.38, 0.22]} outline={false} />
    </group>
  );
}
