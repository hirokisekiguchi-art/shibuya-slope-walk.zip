import { colors } from '../../data/colors';
import { ToonBox } from '../toon/ToonBox';
import { ToonCylinder } from '../toon/ToonCylinder';

interface GuardRailProps {
  position: [number, number, number];
  rotationY?: number;
  length?: number;
}

export function GuardRail({ position, rotationY = 0, length = 3.2 }: GuardRailProps) {
  const postPositions = [-length / 2, 0, length / 2];
  return (
    <group position={position} rotation={[0, rotationY, 0]}>
      <ToonBox size={[length, 0.08, 0.08]} color={'#DEE1D4'} position={[0, 0.72, 0]} />
      <ToonBox size={[length, 0.065, 0.065]} color={'#C8CDC1'} position={[0, 0.42, 0]} />
      {postPositions.map((x) => (
        <ToonCylinder key={x} radiusTop={0.045} radiusBottom={0.045} height={0.8} color={colors.outlineSoft} position={[x, 0.39, 0]} radialSegments={8} />
      ))}
    </group>
  );
}
