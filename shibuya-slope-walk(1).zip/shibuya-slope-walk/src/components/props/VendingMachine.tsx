import { useFrame } from '@react-three/fiber';
import { useRef } from 'react';
import * as THREE from 'three';
import { colors } from '../../data/colors';
import { ToonBox } from '../toon/ToonBox';

interface VendingMachineProps {
  position: [number, number, number];
  rotationY?: number;
  animated?: boolean;
}

export function VendingMachine({ position, rotationY = 0, animated = false }: VendingMachineProps) {
  const panelRef = useRef<THREE.Mesh>(null);

  useFrame(({ clock }) => {
    if (!animated || !panelRef.current) return;
    const pulse = 0.72 + Math.sin(clock.elapsedTime * 1.5) * 0.16;
    panelRef.current.scale.setScalar(pulse);
  });

  return (
    <group position={position} rotation={[0, rotationY, 0]}>
      <ToonBox size={[0.86, 1.72, 0.5]} color={colors.vendingMint} position={[0, 0.86, 0]} />
      <ToonBox size={[0.58, 0.74, 0.035]} color={colors.vendingPanel} position={[0, 1.24, -0.27]} />
      <ToonBox ref={panelRef} size={[0.34, 0.16, 0.04]} color={'#DDEFEA'} position={[0.02, 0.62, -0.29]} />
      {[-0.2, 0, 0.2].map((x) => (
        <ToonBox key={x} size={[0.08, 0.08, 0.045]} color={'#5B7B81'} position={[x, 0.88, -0.31]} />
      ))}
      {[-0.18, 0.02, 0.22].map((x) => (
        <ToonBox key={`can-${x}`} size={[0.08, 0.18, 0.045]} color={'#7CA9B1'} position={[x, 1.34, -0.31]} outline={false} />
      ))}
    </group>
  );
}
