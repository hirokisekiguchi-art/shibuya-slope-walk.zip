import { colors } from '../../data/colors';
import { ToonBox } from '../toon/ToonBox';
import { ToonCylinder } from '../toon/ToonCylinder';

interface UtilityPoleProps {
  position: [number, number, number];
  rotationY?: number;
}

export function UtilityPole({ position, rotationY = 0 }: UtilityPoleProps) {
  return (
    <group position={position} rotation={[0, rotationY, 0]}>
      <ToonCylinder radiusTop={0.09} radiusBottom={0.12} height={4.5} color={'#596765'} position={[0, 2.25, 0]} radialSegments={10} />
      <ToonBox size={[1.5, 0.1, 0.1]} color={colors.outlineSoft} position={[0, 3.75, 0]} />
      <ToonBox size={[0.18, 0.32, 0.18]} color={'#86928D'} position={[-0.55, 3.45, 0]} />
      <ToonBox size={[0.18, 0.32, 0.18]} color={'#86928D'} position={[0.55, 3.45, 0]} />
      <ToonBox size={[2.3, 0.035, 0.035]} color={colors.outline} position={[0.08, 3.95, 0]} rotation={[0, 0, -0.03]} outline={false} />
    </group>
  );
}
