interface StartScreenProps {
  onStart: () => void;
}

export function StartScreen({ onStart }: StartScreenProps) {
  return (
    <div className="start-screen">
      <div className="start-panel">
        <p className="eyebrow">A tiny toon city exploration</p>
        <h1>SHIBUYA SLOPE WALK</h1>
        <p className="lead">渋谷区の坂道や裏路地をモチーフにした、手描き風の3D探索空間です。</p>
        <p className="note">実在の街を完全再現したものではなく、渋谷の路地や坂道を参考にした架空都市です。</p>
        <div className="controls-card" aria-label="操作方法">
          <span>WASD：移動</span>
          <span>Mouse：視点移動</span>
          <span>Shift：少し速く歩く</span>
          <span>Esc：操作解除</span>
        </div>
        <button type="button" onClick={onStart} className="start-button">
          探索をはじめる
        </button>
      </div>
    </div>
  );
}
