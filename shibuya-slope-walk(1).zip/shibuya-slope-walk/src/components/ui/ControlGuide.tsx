interface ControlGuideProps {
  started: boolean;
}

export function ControlGuide({ started }: ControlGuideProps) {
  if (!started) return null;

  return (
    <div className="control-guide">
      <strong>SHIBUYA SLOPE WALK</strong>
      <span>WASD 移動 / Mouse 視点 / Shift 速歩き / Esc 解除</span>
      <small>画面クリックで再ロック</small>
    </div>
  );
}
