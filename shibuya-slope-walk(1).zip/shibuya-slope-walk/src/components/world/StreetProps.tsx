import { roadCenterX, slopeHeight } from '../../utils/terrain';
import { VendingMachine } from '../props/VendingMachine';
import { TrafficCone } from '../props/TrafficCone';
import { StreetSign } from '../props/StreetSign';
import { GuardRail } from '../props/GuardRail';
import { UtilityPole } from '../props/UtilityPole';

function streetPoint(z: number, side: 'left' | 'right', offset = 3.45): [number, number, number] {
  const sign = side === 'left' ? -1 : 1;
  return [roadCenterX(z) + sign * offset, slopeHeight(z) + 0.12, z];
}

export function StreetProps() {
  return (
    <group>
      <VendingMachine position={streetPoint(-5.2, 'left', 3.75)} rotationY={0.18} animated />
      <VendingMachine position={streetPoint(-22.5, 'right', 3.8)} rotationY={-0.25} />

      {[-1.2, -2.2, -12.5, -13.4, -31.5, -32.4].map((z, index) => (
        <TrafficCone key={z} position={streetPoint(z, index % 2 === 0 ? 'right' : 'left', 2.8)} rotationY={index * 0.4} />
      ))}

      <StreetSign position={streetPoint(-7.8, 'left', 3.2)} rotationY={0.25} type="circle" />
      <StreetSign position={streetPoint(-18.6, 'right', 3.15)} rotationY={-0.22} type="arrow" />
      <StreetSign position={streetPoint(-40, 'left', 3.35)} rotationY={0.1} type="board" />

      <GuardRail position={streetPoint(-2.4, 'left', 2.88)} rotationY={0.08} length={3.4} />
      <GuardRail position={streetPoint(-27.6, 'right', 2.92)} rotationY={-0.12} length={3.2} />
      <GuardRail position={streetPoint(-42.2, 'left', 2.95)} rotationY={0.18} length={2.8} />

      <UtilityPole position={streetPoint(-10.3, 'left', 4.32)} rotationY={0.2} />
      <UtilityPole position={streetPoint(-24.8, 'right', 4.2)} rotationY={-0.18} />
      <UtilityPole position={streetPoint(-38.6, 'left', 4.4)} rotationY={0.12} />
    </group>
  );
}
