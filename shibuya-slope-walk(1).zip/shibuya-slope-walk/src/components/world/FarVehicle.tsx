import { useFrame } from '@react-three/fiber';
import { useMemo, useRef } from 'react';
import * as THREE from 'three';
import { colors } from '../../data/colors';
import { roadCenterX, slopeHeight } from '../../utils/terrain';
import { ToonBox } from '../toon/ToonBox';

export function FarVehicle() {
  const carRef = useRef<THREE.Group>(null);
  const startZ = -50;
  const endZ = -34;
  const route = useMemo(() => ({ startZ, endZ, length: Math.abs(endZ - startZ) }), []);

  useFrame(({ clock }) => {
    if (!carRef.current) return;
    const t = (clock.elapsedTime * 0.055) % 1;
    const z = route.startZ + route.length * t;
    const x = roadCenterX(z) + 0.8;
    carRef.current.position.set(x, slopeHeight(z) + 0.18, z);
    carRef.current.rotation.y = 0.04;
  });

  return (
    <group ref={carRef}>
      <ToonBox size={[1.1, 0.34, 1.7]} color={'#88A7A1'} position={[0, 0.26, 0]} />
      <ToonBox size={[0.72, 0.32, 0.78]} color={'#6B8D8A'} position={[0, 0.58, -0.08]} />
      <ToonBox size={[0.18, 0.18, 0.18]} color={colors.outline} position={[-0.48, 0.08, -0.54]} outline={false} />
      <ToonBox size={[0.18, 0.18, 0.18]} color={colors.outline} position={[0.48, 0.08, -0.54]} outline={false} />
      <ToonBox size={[0.18, 0.18, 0.18]} color={colors.outline} position={[-0.48, 0.08, 0.54]} outline={false} />
      <ToonBox size={[0.18, 0.18, 0.18]} color={colors.outline} position={[0.48, 0.08, 0.54]} outline={false} />
    </group>
  );
}
