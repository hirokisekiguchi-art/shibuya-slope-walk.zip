import { buildings } from '../../data/townLayout';
import { TownBuilding } from './TownBuilding';

export function TownBlocks() {
  return (
    <group>
      {buildings.map((building) => (
        <TownBuilding key={building.id} config={building} />
      ))}
    </group>
  );
}
