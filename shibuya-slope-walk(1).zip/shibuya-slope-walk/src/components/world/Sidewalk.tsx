import { roadSegments } from '../../data/townLayout';
import { colors } from '../../data/colors';
import { roadYaw } from '../../utils/terrain';
import { ToonBox } from '../toon/ToonBox';

export function Sidewalks() {
  return (
    <group>
      {roadSegments.map((segment, index) => {
        const yaw = segment.yaw + roadYaw(segment.z) * 0.18;
        return (
          <group key={segment.id} position={[segment.x, segment.y + 0.06, segment.z]} rotation={[-0.052, yaw, 0]}>
            <ToonBox size={[1.42, 0.16, 5.8]} color={index % 2 === 0 ? colors.sidewalk : '#C1BDAA'} position={[-3.05, 0, 0]} />
            <ToonBox size={[1.36, 0.16, 5.8]} color={index % 2 === 0 ? '#BDB9A7' : colors.sidewalk} position={[3.04, 0, 0]} />
            <ToonBox size={[0.2, 0.2, 5.8]} color={colors.curb} position={[-2.25, 0.04, 0]} />
            <ToonBox size={[0.2, 0.2, 5.8]} color={colors.curb} position={[2.25, 0.04, 0]} />
          </group>
        );
      })}
    </group>
  );
}
