import { roadSegments } from '../../data/townLayout';
import { colors } from '../../data/colors';
import { ROAD_HALF_WIDTH, roadCenterX, roadYaw, slopeHeight } from '../../utils/terrain';
import { ToonBox } from '../toon/ToonBox';

export function SlopeRoad() {
  return (
    <group>
      {roadSegments.map((segment, index) => (
        <group
          key={segment.id}
          position={[segment.x, segment.y, segment.z]}
          rotation={[-0.052, segment.yaw + roadYaw(segment.z) * 0.18, 0]}
        >
          <ToonBox size={[ROAD_HALF_WIDTH * 2, 0.12, 5.8]} color={index % 3 === 0 ? colors.roadPatch : colors.road} />
        </group>
      ))}
      <RoadLines />
    </group>
  );
}

function RoadLines() {
  const marks = Array.from({ length: 14 }, (_, index) => {
    const z = 1 - index * 4;
    return { z, x: roadCenterX(z), y: slopeHeight(z) + 0.025, yaw: roadYaw(z) };
  });

  return (
    <group>
      {marks.map((mark, index) => (
        <group key={index} position={[mark.x - 1.55, mark.y, mark.z]} rotation={[-0.052, mark.yaw, 0]}>
          <ToonBox size={[0.1, 0.025, 2.1]} color={colors.whiteLine} outline={false} />
        </group>
      ))}
    </group>
  );
}
