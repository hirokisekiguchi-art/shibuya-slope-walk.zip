import { useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { colors } from '../../data/colors';
import type { BuildingConfig } from '../../data/townLayout';
import { buildingPosition } from '../../data/townLayout';
import { ToonBox } from '../toon/ToonBox';
import { AirConditioner } from '../props/AirConditioner';

interface TownBuildingProps {
  config: BuildingConfig;
}

export function TownBuilding({ config }: TownBuildingProps) {
  const [x, y, z] = buildingPosition(config);
  const frontSign = config.side === 'left' ? 1 : -1;
  const signRef = useRef<THREE.Group>(null);
  const windowRows = Math.max(1, Math.floor(config.height / 1.55) - 1);
  const windowColumns = config.depth > 4.3 ? 3 : 2;

  const windowPositions = useMemo(() => {
    const result: Array<[number, number]> = [];
    for (let row = 0; row < windowRows; row += 1) {
      for (let column = 0; column < windowColumns; column += 1) {
        const localZ = (column - (windowColumns - 1) / 2) * 0.86;
        const localY = -config.height / 2 + 1.45 + row * 1.16;
        result.push([localY, localZ]);
      }
    }
    return result;
  }, [config.depth, config.height, windowColumns, windowRows]);

  useFrame(({ clock }) => {
    if (!signRef.current || config.variant !== 'shop') return;
    signRef.current.rotation.z = Math.sin(clock.elapsedTime * 1.15 + config.z) * 0.035;
  });

  return (
    <group position={[x, y, z]} rotation={[0, config.yaw, 0]}>
      <ToonBox size={[config.width, config.height, config.depth]} color={config.color} />
      {windowPositions.map(([localY, localZ], index) => (
        <ToonBox
          key={`${config.id}-window-${index}`}
          size={[0.08, 0.46, 0.58]}
          color={index % 3 === 0 ? '#D9E8DF' : '#708A8B'}
          position={[frontSign * (config.width / 2 + 0.045), localY, localZ]}
          outline={index % 2 === 0}
          outlineColor={colors.outlineSoft}
        />
      ))}
      <ToonBox
        size={[0.1, 0.88, 0.72]}
        color={'#596765'}
        position={[frontSign * (config.width / 2 + 0.06), -config.height / 2 + 0.5, -config.depth * 0.22]}
      />
      <ToonBox
        size={[0.16, 0.12, 1.24]}
        color={'#8FA09A'}
        position={[frontSign * (config.width / 2 + 0.16), -config.height / 2 + 1.02, -config.depth * 0.22]}
      />
      <group ref={signRef} position={[frontSign * (config.width / 2 + 0.22), -config.height / 2 + 2.05, config.depth * 0.13]}>
        <ToonBox size={[0.18, 0.62, 1.08]} color={config.signColor ?? colors.signOrange} />
        <ToonBox size={[0.19, 0.045, 0.54]} color={colors.outline} position={[frontSign * 0.01, 0.02, 0]} outline={false} />
      </group>
      {config.variant === 'apartment' ? (
        <>
          <ToonBox size={[0.2, 0.08, 1.8]} color={'#6B7773'} position={[frontSign * (config.width / 2 + 0.22), -0.45, 0.65]} />
          <ToonBox size={[0.2, 0.08, 1.5]} color={'#6B7773'} position={[frontSign * (config.width / 2 + 0.22), 1.05, -0.55]} />
        </>
      ) : null}
      <ToonBox
        size={[0.08, config.height * 0.76, 0.08]}
        color={colors.outlineSoft}
        position={[frontSign * (config.width / 2 + 0.08), 0.2, config.depth / 2 - 0.38]}
        outline={false}
      />
      <AirConditioner position={[frontSign * (config.width / 2 + 0.13), config.height * 0.08, -config.depth * 0.18]} frontSign={frontSign} />
      {config.height > 5.8 ? (
        <AirConditioner position={[frontSign * (config.width / 2 + 0.13), config.height * 0.28, config.depth * 0.22]} frontSign={frontSign} />
      ) : null}
      <ToonBox
        size={[config.width * 0.82, 0.22, config.depth * 0.84]}
        color={'#7B8278'}
        position={[0, config.height / 2 + 0.12, 0]}
      />
    </group>
  );
}
