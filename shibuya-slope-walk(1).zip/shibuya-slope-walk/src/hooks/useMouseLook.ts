import { useEffect, useRef } from 'react';
import * as THREE from 'three';

export function useMouseLook(enabled: boolean) {
  const yaw = useRef(0);
  const pitch = useRef(-0.05);

  useEffect(() => {
    if (!enabled) return undefined;

    const handleMouseMove = (event: MouseEvent) => {
      if (!document.pointerLockElement) return;
      yaw.current -= event.movementX * 0.0021;
      pitch.current = THREE.MathUtils.clamp(pitch.current - event.movementY * 0.0014, -0.34, 0.22);
    };

    window.addEventListener('mousemove', handleMouseMove);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, [enabled]);

  return { yaw, pitch };
}
